//
//  ViewController.swift
//  BountyList
//
//  Created by inooph on 2021/04/04.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

